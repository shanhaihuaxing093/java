(() => {
  "use strict";

  // ---------- 基础设置 ----------
  const COLS = 20, ROWS = 20;
  const canvas = document.getElementById("board");
  const ctx = canvas.getContext("2d");
  const scoreEl = document.getElementById("score");
  const bestEl = document.getElementById("best");
  const startScreen = document.getElementById("startScreen");
  const pauseScreen = document.getElementById("pauseScreen");
  const overScreen = document.getElementById("overScreen");
  const finalScore = document.getElementById("finalScore");
  const overHint = document.getElementById("overHint");

  const BEST_KEY = "snake_best_v1";
  const THEME_KEY = "snake_theme_v1";

  // 高分持久化
  let best = parseInt(localStorage.getItem(BEST_KEY) || "0", 10) || 0;
  bestEl.textContent = best;

  // 主题持久化
  const themeBtn = document.getElementById("themeBtn");
  if (localStorage.getItem(THEME_KEY) === "light") document.body.classList.add("light");
  themeBtn.addEventListener("click", () => {
    const isLight = document.body.classList.toggle("light");
    localStorage.setItem(THEME_KEY, isLight ? "light" : "dark");
    drawStatic();
  });

  // ---------- 游戏状态 ----------
  let snake, dir, nextDir, food, score, speed, running, paused, gameOver, acc, last;

  function reset() {
    snake = [{ x: 10, y: 10 }, { x: 9, y: 10 }, { x: 8, y: 10 }];
    dir = { x: 1, y: 0 };
    nextDir = { x: 1, y: 0 };
    score = 0;
    scoreEl.textContent = "0";
    paused = false;
    gameOver = false;
    acc = 0;
    placeFood();
  }

  function placeFood() {
    const free = [];
    for (let y = 0; y < ROWS; y++)
      for (let x = 0; x < COLS; x++)
        if (!snake.some(s => s.x === x && s.y === y)) free.push({ x, y });
    food = free.length ? free[Math.floor(Math.random() * free.length)] : null;
  }

  // ---------- 输入 ----------
  const keyMap = {
    ArrowUp: { x: 0, y: -1 }, ArrowDown: { x: 0, y: 1 },
    ArrowLeft: { x: -1, y: 0 }, ArrowRight: { x: 1, y: 0 },
    w: { x: 0, y: -1 }, s: { x: 0, y: 1 }, a: { x: -1, y: 0 }, d: { x: 1, y: 0 },
    W: { x: 0, y: -1 }, S: { x: 0, y: 1 }, A: { x: -1, y: 0 }, D: { x: 1, y: 0 },
  };

  function setDir(nd) {
    if (nd.x === -dir.x && nd.y === -dir.y) return; // 不能直接掉头
    nextDir = nd;
  }

  window.addEventListener("keydown", e => {
    if (keyMap[e.key]) {
      e.preventDefault();
      if (!running && !paused) return;
      setDir(keyMap[e.key]);
    } else if (e.key === " " || e.key === "Spacebar") {
      e.preventDefault();
      togglePause();
    }
  });

  // 屏幕方向按钮
  document.querySelectorAll(".ctrl").forEach(btn => {
    const map = { up: { x: 0, y: -1 }, down: { x: 0, y: 1 }, left: { x: -1, y: 0 }, right: { x: 1, y: 0 } };
    btn.addEventListener("click", () => { if (running) setDir(map[btn.dataset.dir]); });
  });

  // 触屏滑动
  let touchStart = null;
  canvas.addEventListener("touchstart", e => {
    touchStart = { x: e.touches[0].clientX, y: e.touches[0].clientY };
  }, { passive: true });
  canvas.addEventListener("touchmove", e => {
    if (!touchStart || !running) return;
    const dx = e.touches[0].clientX - touchStart.x;
    const dy = e.touches[0].clientY - touchStart.y;
    if (Math.abs(dx) + Math.abs(dy) < 24) return;
    if (Math.abs(dx) > Math.abs(dy)) setDir({ x: dx > 0 ? 1 : -1, y: 0 });
    else setDir({ x: 0, y: dy > 0 ? 1 : -1 });
    touchStart = null;
  }, { passive: true });

  // ---------- 音效 ----------
  let soundOn = true;
  const soundBtn = document.getElementById("soundBtn");
  let audioCtx = null;
  function beep(freq, dur = 0.07, type = "square", vol = 0.04) {
    if (!soundOn) return;
    try {
      audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
      const o = audioCtx.createOscillator(), g = audioCtx.createGain();
      o.type = type; o.frequency.value = freq;
      g.gain.value = vol;
      o.connect(g); g.connect(audioCtx.destination);
      o.start();
      g.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + dur);
      o.stop(audioCtx.currentTime + dur);
    } catch (_) {}
  }
  soundBtn.addEventListener("click", () => {
    soundOn = !soundOn;
    soundBtn.textContent = soundOn ? "🔊 音效" : "🔇 静音";
  });

  // ---------- 难度 ----------
  let selectedSpeed = 100;
  document.querySelectorAll(".diff").forEach(b => {
    b.addEventListener("click", () => {
      document.querySelectorAll(".diff").forEach(x => x.classList.remove("active"));
      b.classList.add("active");
      selectedSpeed = parseInt(b.dataset.speed, 10);
    });
  });

  // ---------- 主循环 ----------
  function step() {
    dir = nextDir;
    const head = { x: snake[0].x + dir.x, y: snake[0].y + dir.y };

    // 撞墙
    if (head.x < 0 || head.y < 0 || head.x >= COLS || head.y >= ROWS) {
      return endGame();
    }

    // 撞自己（吃食物时尾巴不移动，需整体判定；否则排除即将离开的尾格）
    const willEat = food && head.x === food.x && head.y === food.y;
    const body = willEat ? snake : snake.slice(0, -1);
    if (body.some(s => s.x === head.x && s.y === head.y)) {
      return endGame();
    }

    snake.unshift(head);

    if (willEat) {
      score += 10;
      scoreEl.textContent = score;
      beep(660, 0.08);
      placeFood();
      // 每得 50 分略微加速
      if (score % 50 === 0) speed = Math.max(35, speed - 4);
    } else {
      snake.pop();
    }
  }

  function loop(ts) {
    if (!running) return;
    if (!last) last = ts;
    const dt = ts - last;
    last = ts;

    if (!paused && !gameOver) {
      acc += dt;
      while (acc >= speed) {
        acc -= speed;
        step();
        if (gameOver) break;
      }
      draw();
    }
    requestAnimationFrame(loop);
  }

  // ---------- 绘制 ----------
  function drawStatic() {
    const w = canvas.width, h = canvas.height;
    const cw = w / COLS, ch = h / ROWS;
    ctx.fillStyle = getComputedStyle(document.body).getPropertyValue("--board").trim() || "#0b1020";
    ctx.fillRect(0, 0, w, h);
    ctx.strokeStyle = getComputedStyle(document.body).getPropertyValue("--grid").trim() || "rgba(255,255,255,0.04)";
    ctx.lineWidth = 1;
    for (let i = 1; i < COLS; i++) {
      ctx.beginPath(); ctx.moveTo(i * cw, 0); ctx.lineTo(i * cw, h); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(0, i * ch); ctx.lineTo(w, i * ch); ctx.stroke();
    }
  }

  function roundRect(x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }

  function draw() {
    drawStatic();
    const w = canvas.width, h = canvas.height;
    const cw = w / COLS, ch = h / ROWS;
    const accent = getComputedStyle(document.body).getPropertyValue("--accent").trim() || "#36e27b";
    const foodColor = getComputedStyle(document.body).getPropertyValue("--food").trim() || "#ff5d73";

    // 食物
    if (food) {
      ctx.fillStyle = foodColor;
      const fx = food.x * cw + cw / 2, fy = food.y * ch + ch / 2;
      const pulse = 0.5 + 0.5 * Math.sin(Date.now() / 200);
      ctx.shadowColor = foodColor; ctx.shadowBlur = 12 + pulse * 6;
      ctx.beginPath();
      ctx.arc(fx, fy, cw * 0.32, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;
    }

    // 蛇身
    for (let i = snake.length - 1; i >= 0; i--) {
      const s = snake[i];
      const t = i / Math.max(1, snake.length - 1);
      ctx.fillStyle = i === 0 ? accent : mix(accent, "#0b1020", t * 0.55);
      roundRect(s.x * cw + 1.5, s.y * ch + 1.5, cw - 3, ch - 3, 6);
      ctx.fill();
    }
    // 蛇眼
    const head = snake[0];
    ctx.fillStyle = "#06140b";
    const ex = head.x * cw, ey = head.y * ch;
    const e1 = { x: ex + cw * (dir.x ? 0.7 : 0.35), y: ey + ch * (dir.y ? 0.7 : 0.35) };
    const e2 = { x: ex + cw * (dir.x ? 0.7 : 0.65), y: ey + ch * (dir.y ? 0.7 : 0.65) };
    if (dir.x) { ctx.beginPath(); ctx.arc(e1.x, ey + ch * 0.3, 2, 0, 7); ctx.arc(e1.x, ey + ch * 0.7, 2, 0, 7); ctx.fill(); }
    else { ctx.beginPath(); ctx.arc(ex + cw * 0.3, e1.y, 2, 0, 7); ctx.arc(ex + cw * 0.7, e1.y, 2, 0, 7); ctx.fill(); }
  }

  function mix(a, b, t) {
    const pa = hex(a), pb = hex(b);
    const r = Math.round(pa[0] + (pb[0] - pa[0]) * t);
    const g = Math.round(pa[1] + (pb[1] - pa[1]) * t);
    const bl = Math.round(pa[2] + (pb[2] - pa[2]) * t);
    return `rgb(${r},${g},${bl})`;
  }
  function hex(c) {
    c = c.replace("#", "");
    if (c.length === 3) c = c.split("").map(x => x + x).join("");
    return [parseInt(c.slice(0, 2), 16), parseInt(c.slice(2, 4), 16), parseInt(c.slice(4, 6), 16)];
  }

  // ---------- 流程控制 ----------
  function startGame() {
    reset();
    speed = selectedSpeed;
    running = true; paused = false; gameOver = false; last = 0;
    startScreen.classList.add("hidden");
    overScreen.classList.add("hidden");
    pauseScreen.classList.add("hidden");
    beep(440, 0.06, "sine");
    requestAnimationFrame(loop);
  }

  function togglePause() {
    if (!running || gameOver) return;
    paused = !paused;
    pauseScreen.classList.toggle("hidden", !paused);
  }

  function endGame() {
    gameOver = true; running = false;
    beep(160, 0.25, "sawtooth", 0.05);
    if (score > best) {
      best = score;
      localStorage.setItem(BEST_KEY, String(best));
      bestEl.textContent = best;
      overHint.textContent = "🎉 新纪录！";
    } else {
      overHint.textContent = `距最高分还差 ${best - score} 分`;
    }
    finalScore.textContent = score;
    overScreen.classList.remove("hidden");
  }

  document.getElementById("startBtn").addEventListener("click", startGame);
  document.getElementById("restartBtn").addEventListener("click", startGame);
  document.getElementById("resumeBtn").addEventListener("click", togglePause);
  document.getElementById("pauseBtn").addEventListener("click", togglePause);

  // 初始静态画面
  drawStatic();
})();
